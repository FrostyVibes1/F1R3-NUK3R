HELP:
Currentley Unavailable due to amount of mass reports.




fqa:

Q: How to install?
A: Run install.bat and then F1R3-NUK3R.exe