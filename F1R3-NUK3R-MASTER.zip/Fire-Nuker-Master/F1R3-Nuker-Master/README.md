FIRE NUKER WAS MADE BY SXZZ#4342





UI DESIGN:
f32#6969






Thank you all for using F1R3-Nuk3r